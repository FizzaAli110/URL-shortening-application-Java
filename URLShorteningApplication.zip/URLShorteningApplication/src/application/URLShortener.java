package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;  
import java.util.Date;

/*
 * URL Shortener
 */
public class URLShortener {
	// storage for generated keys
	private HashMap<String, String> keyMap; // key-url map
	private HashMap<String, String> valueMap;// url-key map to quickly check
												// whether an url is
	// already entered in our system
	private String domain; // Use this attribute to generate urls for a custom
							// domain name defaults to http://fkt.in
	private char myChars[]; // This array is used for character to number
							// mapping
	private Random myRand; // Random object used to generate random integers
	private int keyLength; // the key length in URL defaults to 8

	// Default Constructor
	URLShortener() {
		keyMap = new HashMap<String, String>();
		valueMap = new HashMap<String, String>();
		myRand = new Random();
		keyLength = 8;
		myChars = new char[62];
		for (int i = 0; i < 62; i++) {
			int j = 0;
			if (i < 10) {
				j = i + 48;
			} else if (i > 9 && i <= 35) {
				j = i + 55;
			} else {
				j = i + 61;
			}
			myChars[i] = (char) j;
		}
		domain = "http://fkt.in";
	}

	// Constructor which enables you to define tiny URL key length and base URL
	// name
	URLShortener(int length, String newDomain) {
		this();
		this.keyLength = length;
		if (!newDomain.isEmpty()) {
			newDomain = sanitizeURL(newDomain);
			domain = newDomain;
		}
	}

	// shortenURL
	// the public method which can be called to shorten a given URL
	public String shortenURL(String longURL) {
		String shortURL = "";
			longURL = sanitizeURL(longURL);
			if (valueMap.containsKey(longURL)) {
				shortURL = domain + "/" + valueMap.get(longURL);
			} else {
				shortURL = domain + "/" + getKey(longURL);
			}
		// add http part
		return shortURL;
	}

	// expandURL
	// public method which returns back the original URL given the shortened url
	public String expandURL(String shortURL) {
		String longURL = "";
		String key = shortURL.substring(domain.length() + 1);
		longURL = keyMap.get(key);
		return longURL;
	}

	// Validate URL
	// not implemented, but should be implemented to check whether the given URL
	// is valid or not
	boolean validateURL(String url) {
		boolean valid=false;
		try
		{
			//1. Get a connection to the database
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/url-shortener", "root", "admin");
			//2. Create a statement
			Statement myStmt = myConn.createStatement();
			//3. Execute a SQL Query
			ResultSet myRs = myStmt.executeQuery("Select * from url");
			//4. Process the result set			
			while (myRs.next())
			{
			   if(myRs.getString("long_url").equals(url))
			   {  
				   valid =  true;
			       return valid;
			   }
			}
			
		}
		catch (Exception exc)
		{
			exc.printStackTrace();
		}
		return valid;
	}

	// sanitizeURL
	// This method should take care various issues with a valid url
	// e.g. www.google.com,www.google.com/, http://www.google.com,
	// http://www.google.com/
	// all the above URL should point to same shortened URL
	// There could be several other cases like these.
	String sanitizeURL(String url) {
		if (url.substring(0, 7).equals("http://"))
			url = url.substring(7);

		if (url.substring(0, 8).equals("https://"))
			url = url.substring(8);

		if (url.charAt(url.length() - 1) == '/')
			url = url.substring(0, url.length() - 1);
		return url;
	}

	/*
	 * Get Key method
	 */
	private String getKey(String longURL) {
		String key;
		key = generateKey();
		keyMap.put(key, longURL);
		valueMap.put(longURL, key);
		return key;
	}

	// generateKey
	private String generateKey() {
		String key = "";
		boolean flag = true;
		while (flag) {
			key = "";
			for (int i = 0; i <= keyLength; i++) {
				key += myChars[myRand.nextInt(62)];
			}
			// System.out.println("Iteration: "+ counter + "Key: "+ key);
			if (!keyMap.containsKey(key)) {
				flag = false;
			}
		}
		return key;
	}

	//Method overloading to insert data in database
	public void insertData(String longURL, String shortURL, String DateNow, String DateExpired)
	{
		try
		{
			//1. Get a connection to the database
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/url-shortener", "root", "admin");
			//2. Create a statement
			Statement myStmt = myConn.createStatement();
			//3. Execute a SQL Query
			//ResultSet myRs = myStmt.executeQuery("INSERT INTO url");
			// the mysql insert statement
		      String query = " insert into url (long_url, short_url, date_created, date_expired)"
		        + " values (?, ?, ?, ?)";

		      // create the mysql insert preparedstatement
		      PreparedStatement preparedStmt = myConn.prepareStatement(query);
		      preparedStmt.setString (1, longURL);
		      preparedStmt.setString (2, shortURL);
		      preparedStmt.setString  (3, DateNow);
		      preparedStmt.setString  (4, DateExpired);

		      
		      // execute the preparedstatement
		      preparedStmt.execute();
		      
		      myConn.close();

		}
		catch (Exception exc)
		{
			exc.printStackTrace();
		}
	}
	
	//Method to retrieve short URLs for display
	public static ArrayList<String> getShortURL()
	{
		ArrayList<String> arrayList = new ArrayList<>();
		try
		{
			//1. Get a connection to the database
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/url-shortener", "root", "admin");
			//2. Create a statement
			Statement myStmt = myConn.createStatement();
			//3. Execute a SQL Query
			ResultSet myRs = myStmt.executeQuery("Select * from url");
			System.out.println();
			//4. Process the result set
			while (myRs.next())
			{
				arrayList.add(myRs.getString("short_url"));
			}
		}
		catch (Exception exc)
		{
			exc.printStackTrace();
		}
		return arrayList;
	}
	
	public static String getDate(String url)
	{
		String Date = null;
		try
		{
			//1. Get a connection to the database
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/url-shortener", "root", "admin");
			//2. Create a statement
			Statement myStmt = myConn.createStatement();
			//3. Execute a SQL Query
			String query = "Select * from url where short_url = '"+ url+"'";
			ResultSet myRs = myStmt.executeQuery(query);
			//4. Process the result set
			while (myRs.next())
			{
			Date = myRs.getString("date_expired");
			}
			System.out.println(Date);
			
		}
		catch (Exception exc)
		{
			exc.printStackTrace();
		}
		return Date;
	}
	
	public static String[] getData(String url)
	{
		String[] data = new String[5];
		int i=0;
		try
		{
			//1. Get a connection to the database
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/url-shortener", "root", "admin");
			//2. Create a statement
			Statement myStmt = myConn.createStatement();
			//3. Execute a SQL Query
			String query = "Select * from url where short_url = '"+ url+"'";
			ResultSet myRs = myStmt.executeQuery(query);
			//4. Process the result set
			while (myRs.next())
			{
			data[1] = myRs.getString("short_url");
			data[2] = myRs.getString("long_url");
			data[3] = myRs.getString("date_created");
			data[4] = myRs.getString("date_expired");
			}
			
		}
		catch (Exception exc)
		{
			exc.printStackTrace();
		}
		return data;
	}
	
	// Method to prepare values for insertion in database
	public static boolean insertData(String inputURL) {
		//call method to shorten URL
		URLShortener u = new URLShortener(5, "www.bitly.com/");
		//check if the url exists already. Returns false if url exists or insert data in db if it doesn't
		Boolean valid = u.validateURL(inputURL);
		
		if(!valid)
		{
			//shorten the input URL
			String shortURL = u.shortenURL(inputURL);
			System.out.println(shortURL);
			//get current date
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
			Calendar c = Calendar.getInstance();
			c.setTime(Calendar.getInstance().getTime()); // Now use today date.
			String TodaysDate = sdf.format(c.getTime());
			
			c.add(Calendar.DATE, 5); // Adding 5 days
			String ExpirationDate = sdf.format(c.getTime());		
			
			//insert into table
			u.insertData(inputURL, shortURL, TodaysDate, ExpirationDate);
			return true;
			//Retrieve Data
			//u.getData();
		}
		
		else
		{
			return false;
		}
	}
	
	public static boolean checkExpiration(String url) throws ParseException
	{
		boolean expired;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		Calendar c = Calendar.getInstance();
		c.setTime(Calendar.getInstance().getTime()); // Now use today date.
		String TodaysDate = sdf.format(c.getTime());
		Date date1 = sdf.parse(TodaysDate);
		String expiryDate = URLShortener.getDate(url);
		Date date2 = sdf.parse(expiryDate);
		 if (date1.compareTo(date2) < 0) {
	           expired= false;
	      }
		 else
			 expired = true;
  
		return expired;
		
	}
}