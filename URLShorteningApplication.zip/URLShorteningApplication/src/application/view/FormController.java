package application.view;

import java.awt.ScrollPane;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import application.AlertHelper;
import application.URLShortener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;

public class FormController {
    @FXML
    private TextField urlField;

    @FXML
    private Button submitButton;
    
    
    @FXML
    protected void handleSubmitButtonAction(ActionEvent event) {
        Window owner = submitButton.getScene().getWindow();
        String URL = urlField.getText();
        if(URL.isEmpty()) {
            AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", 
                    "Please enter a valid URL");
            return;
        }
        else
        {

              boolean Status = URLShortener.insertData(URL);
              if(Status)
              {
            	  AlertHelper.showAlert(Alert.AlertType.CONFIRMATION, owner, "Insertion Successful!", 
                          "Insertion Completed " + urlField.getText());
            	  urlField.clear();
              }
              else
            	  AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!", 
                          "URL Already exists");
        }
    }
    
    @FXML
    private void handlenewRURLButtonAction(ActionEvent event) throws IOException {
        Stage stage;
        Parent root;
        stage=(Stage) ((Button)(event.getSource())).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Registration_form.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }   
    
    @FXML
    private void handlebackButtonAction(ActionEvent event) throws IOException {
        Stage stage;
        Parent root;
        stage=(Stage) ((Button)(event.getSource())).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("MainMenu_form.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void handleshowURLAction(ActionEvent event) throws IOException {
    	 Stage stage;
    	 
    	 stage=(Stage) ((Button)(event.getSource())).getScene().getWindow(); 
         
        	    //URLShortener u = new URLShortener();       	    
    	        final ArrayList<String> captions = URLShortener.getShortURL();
        	    final Hyperlink[] hpls = new Hyperlink[captions.size()];
        	 
        	     for (int i = 0; i < captions.size(); i++) {
        	            final Hyperlink hpl = hpls[i] = new Hyperlink(captions.get(i));
        	           
        	            hpl.setOnAction(new EventHandler<ActionEvent>() {
        	                @Override
        	                public void handle(ActionEvent e) {
        	                	try {
        	                		String url = hpl.getText();
        	                		Boolean expired = URLShortener.checkExpiration(url);
									 if(expired)
						              {
						            	  AlertHelper.showAlert(Alert.AlertType.ERROR, stage, "Form Error!", 
						                          "URL has expired");
						            	  urlField.clear();
						              }
						              else
						              {
						            	  showHyperLink(stage,url);

						              }
						        }
								 catch (ParseException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
        	                	
        	                	
        	                }

							@FXML
							private void handleshowURLAction(ActionEvent event) throws IOException {
								 Stage stage;
								 
								 stage=(Stage) ((Button)(event.getSource())).getScene().getWindow(); 
							     
							    	    //URLShortener u = new URLShortener();       	    
								        final ArrayList<String> captions = URLShortener.getShortURL();
							    	    final Hyperlink[] hpls = new Hyperlink[captions.size()];
							    	 
							    	     for (int i = 0; i < captions.size(); i++) {
							    	            final Hyperlink hpl = hpls[i] = new Hyperlink(captions.get(i));
							    	           
							    	            hpl.setOnAction(new EventHandler<ActionEvent>() {
							    	                @Override
							    	                public void handle(ActionEvent e) {
							    	                	try {
							    	                		String url = hpl.getText();
							    	                		Boolean expired = URLShortener.checkExpiration(url);
															 if(expired)
												              {
												            	  AlertHelper.showAlert(Alert.AlertType.ERROR, stage, "Form Error!", 
												                          "URL has expired");
												            	  urlField.clear();
												              }
												              else
												              {
												            	  showHyperLink(stage,url);
							
												              }
												        }
														 catch (ParseException e1) {
															// TODO Auto-generated catch block
															e1.printStackTrace();
														} catch (IOException e1) {
															// TODO Auto-generated catch block
															e1.printStackTrace();
														}
							    	                	
							    	                	
							    	                }
							
							    	            });
							    	        }
							    	 
							    	        BorderPane pane = new BorderPane();
							    	        pane = FXMLLoader.load(getClass().getResource("Tableview.fxml"));	                
							        	 	VBox vbox = new VBox();
							        	 	vbox.setSpacing(10);
							        	 	pane.setCenter(vbox);
							        	 	vbox.getChildren().addAll(hpls);
							        	 	Scene scene= new Scene(pane, 400, 400);
							        	 	stage.setScene(scene);
							        	 	stage.show();
							  	  
							    	    }

        	            });
        	        }
        	 
        	        BorderPane pane = new BorderPane();
        	        pane = FXMLLoader.load(getClass().getResource("Tableview.fxml"));	                
	        	 	VBox vbox = new VBox();
	        	 	vbox.setSpacing(10);
	        	 	pane.setCenter(vbox);
	        	 	vbox.getChildren().addAll(hpls);
	        	 	Scene scene= new Scene(pane, 400, 400);
	        	 	stage.setScene(scene);
	        	 	stage.show();
      	  
        	    }

	protected void showHyperLink(Stage stage, String url) throws IOException {
		// TODO Auto-generated method stub
		
		BorderPane pane = new BorderPane();
		Label Label1 = new Label();
		Label Label2 = new Label();
		Label Label3 = new Label();
		String[] data = URLShortener.getData(url);
		Label1.setText(data[1]);
		Label2.setText(data[2]);
		Label3.setText(data[4]);
		
	    pane = FXMLLoader.load(getClass().getResource("Detailview.fxml"));	                
 	 	VBox vbox = new VBox();
 	 	vbox.setSpacing(13);
 	 	pane.setCenter(vbox);
 	 	vbox.getChildren().add(Label1);
 	 	vbox.getChildren().add(Label2);
 	 	vbox.getChildren().add(Label3);
 	 	Scene scene= new Scene(pane, 350, 300);
 	 	stage.setScene(scene);
 	 	stage.show();
	}
         
    
}